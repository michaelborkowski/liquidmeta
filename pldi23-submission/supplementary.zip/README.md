# liquidmeta

This anonymous supplementary material consists of two artifacts
  - a complete mechanization of our proof in Coq, in the `coq-SystemRF` directory
  - a complete mechanization of our proof in LiquidHaskell in the `liquid-SystemRF` directory.

Each directory contains a README.md file with software requirements and instructions for running/checking the mechanization. Please see those files for more details.
